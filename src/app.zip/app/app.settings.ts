export class AppSettings {
    // public static LOGIN_API: string = 'http://192.168.0.146/erpserver/api/validLogin';
     public static LOGIN_API: string = 'http://210.16.79.137/raghuerp/server/api/validLogin';
    
    
      // public static LOGIN_API: string = 'http://localhost/issue_register/api/loginCheck';
    public static USER_DESIGNATIONS_VIEW_API: string = 'http://192.168.0.111/hmsserver/Api/userdesignationsview';
    public static UPDATE_YEAR_API: string = 'http://192.168.0.111/hmsserver/Api/updateyear';

    // VENKAT
    public static ADD_TYPE_API: string = 'http://192.168.0.111/hmsserver/Api/addtype';
    public static ROOMTYPE_API: string = 'http://localhost/hmsserver/Api/roomtype';
    public static ADD_REGISTRATION_API: string = 'http://192.168.0.111/hmsserver/Api/addregistration';
      public static GETLIST_API: string = 'http://localhost/hmsserver/Api/getlist';
      public static INSERTLIST_API:string = 'http://localhost/hmsserver/Api/insertlist';
      public static ITEMOUTLIST_API:string = 'http://localhost/hmsserver/Api/itemoutlist';
      public static ADDNEWITEM_API: string ='http://localhost/hmsserver/Api/addnewitem';
      public static MENULIST_API: string = 'http://localhost/hmsserver/Api/menulist';
      public static  GETMENULIST_API: string = 'http://localhost/hmsserver/Api/getmenulist';
      public static UPDATELIST_API: string = 'http://localhost/hmsserver/Api/updatelist';
      public static STOCKREGISTER_API: string = 'http://localhost/hmsserver/Api/stockRegister';
      public static STOCKBALANCE_API: string = 'http://localhost/hmsserver/Api/stockBalance';
      public static GETUNITS_API: string ='http://localhost/hmsserver/APi/getunits';
      public static PURCHASERLIST_API: string = 'http://localhost/hmsserver/Api/purchaserlist';
      public static PURCHASEITEMSLIST_API: string = 'http://localhost/hmsserver/Api/purchaseItemsList';
      public static UPDATEMATERIALLIST_API: string = 'http://localhost/hmsserver/Api/updatematerialslist';
//public static PURCHASERLIST_API: string = 'http://localhost/hmsserver/Api/purchaserlist';
public static DELETEITEM_API:string = 'http://localhost/hmsserver/Api/deleteitem';
      
}